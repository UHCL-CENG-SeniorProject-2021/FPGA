#!/bin/bash

ghdl -a zybo_top.vhd
ghdl -a product_top.vhd
